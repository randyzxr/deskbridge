/*
 * Deskflow -- mouse and keyboard sharing utility
 * SPDX-FileCopyrightText: (C) 2025 - 2026 Deskflow Developers
 * SPDX-FileCopyrightText: (C) 2012 Synergy App Ltd
 * SPDX-FileCopyrightText: (C) 2002 Chris Schoeneman
 * SPDX-License-Identifier: GPL-2.0-only WITH LicenseRef-OpenSSL-Exception
 */

#include "deskflow/ClientApp.h"

#include "base/Event.h"
#include "base/IEventQueue.h"
#include "base/Log.h"
#include "client/Client.h"
#include "common/ExitCodes.h"
#include "common/PlatformInfo.h"
#include "common/Settings.h"
#include "deskflow/Computer.h"
#include "deskflow/DisplayException.h"
#include "deskflow/ipc/CoreIpc.h"
#include "net/NetworkAddress.h"
#include "net/SocketException.h"
#include "net/SocketMultiplexer.h"
#include "net/TCPSocketFactory.h"

#if defined(Q_OS_WIN)
#include "platform/MSWindowsComputer.h"
#endif

#include <QFileInfo> // Must include before XWindowsComputer to avoid conflicts with xlib.h

#if WINAPI_XWINDOWS
#include "platform/XWindowsComputer.h"
#endif

#if WINAPI_LIBEI
#include "platform/EiComputer.h"
#endif

#if defined(Q_OS_MACOS)
#include "platform/OSXComputer.h"
#endif

#include <memory>

ClientApp::ClientApp(IEventQueue *events, const QString &processName) : App(events, processName)
{
  // do nothing
}

void ClientApp::parseArgs()
{
  // save server addresses (comma-separated list supported)
  if (const auto addressList = Settings::value(Settings::Client::RemoteHost).toString(); !addressList.isEmpty()) {
    const int port = Settings::value(Settings::Core::Port).toInt();
    const QStringList addresses = addressList.split(',', Qt::SkipEmptyParts);

    for (const QString &addr : addresses) {
      const QString trimmedAddr = addr.trimmed();
      if (trimmedAddr.isEmpty()) {
        continue;
      }

      try {
        NetworkAddress netAddr(trimmedAddr.toStdString(), port);
        netAddr.resolve();
        m_serverAddresses.append(netAddr);
        LOG_DEBUG("added server address: %s", qPrintable(trimmedAddr));
      } catch (SocketAddressException &e) {
        // allow an address that we can't look up if we're restartable.
        // we'll try to resolve the address each time we connect to the
        // server.  a bad port will never get better.
        if (e.getError() == SocketAddressException::SocketError::BadPort) {
          LOG_CRIT("%s: %s" BYE, qPrintable(processName()), e.what(), qPrintable(processName()));
          bye(s_exitFailed);
        } else {
          // Still add it - we'll try to resolve later
          NetworkAddress netAddr(trimmedAddr.toStdString(), port);
          m_serverAddresses.append(netAddr);
          LOG_WARN("could not resolve address '%s': %s (will retry later)", qPrintable(trimmedAddr), e.what());
        }
      }
    }

    if (m_serverAddresses.isEmpty()) {
      LOG_CRIT("%s: no valid server addresses specified" BYE, qPrintable(processName()), qPrintable(processName()));
      bye(s_exitFailed);
    }

    LOG_INFO("configured %zu server address(es)", static_cast<size_t>(m_serverAddresses.size()));
  }
}

const char *ClientApp::daemonName() const
{
  if (deskflow::platform::isWindows())
    return "Deskflow Client";
  return "deskflow-client";
}

deskflow::Computer *ClientApp::createComputer()
{
#if defined(Q_OS_WIN) || defined(Q_OS_MACOS)
  const auto languageSync = Settings::value(Settings::Client::LanguageSync).toBool();
  LOG_INFO("keyboard language sync is %s", languageSync ? "enabled" : "disabled");
#endif

#if defined(Q_OS_WIN)
  return new deskflow::Computer(
      new MSWindowsComputer(false, Settings::value(Settings::Core::UseHooks).toBool(), getEvents(), languageSync),
      getEvents()
  );
#elif defined(Q_OS_MACOS)
  return new deskflow::Computer(new OSXComputer(getEvents(), false, languageSync), getEvents());
#else
  if (deskflow::platform::isWayland()) {
#if WINAPI_LIBEI
    LOG_INFO("detected wayland platform");
    return new deskflow::Computer(new deskflow::EiComputer(false, getEvents(), true), getEvents());
#else
    throw XNoEiSupport();
#endif
  }
#if WINAPI_XWINDOWS
  LOG_INFO("detected X11 platform");
  return new deskflow::Computer(
      new XWindowsComputer(qPrintable(Settings::value(Settings::Core::Display).toString()), false, getEvents()),
      getEvents()
  );
#endif
#endif // end os check
}

deskflow::Computer *ClientApp::openClientComputer()
{
  deskflow::Computer *computer = createComputer();
  getEvents()->addHandler(EventTypes::ComputerError, computer->getEventTarget(), [this](const auto &) {
    handleComputerError();
  });
  return computer;
}

void ClientApp::closeClientComputer(deskflow::Computer *computer)
{
  if (computer != nullptr) {
    getEvents()->removeHandler(EventTypes::ComputerError, computer->getEventTarget());
    delete computer;
  }
}

void ClientApp::handleClientRestart(const Event &, EventQueueTimer *timer)
{
  // discard old timer
  getEvents()->deleteTimer(timer);
  getEvents()->removeHandler(EventTypes::Timer, timer);

  // reconnect
  startClient();
}

void ClientApp::scheduleClientRestart(double retryTime)
{
  LOG_DEBUG("retry in %.0f seconds", retryTime);
  ipcSendToClient("retryIn", QString::number(retryTime, 'f', 0));
  // install a timer and handler to retry later
  EventQueueTimer *timer = getEvents()->newOneShotTimer(retryTime, nullptr);
  getEvents()->addHandler(EventTypes::Timer, timer, [this, timer](const auto &e) { handleClientRestart(e, timer); });
}

void ClientApp::handleClientConnected()
{
  LOG_DEBUG("connected to server");
  ipcSendConnectionState(deskflow::core::ConnectionState::Connected);
  // Reset server index on successful connection
  m_currentServerIndex = 0;
  m_lastServerAddressIndex = 0;
}

void ClientApp::handleClientFailed(const Event &e)
{
  if ((++m_lastServerAddressIndex) < m_client->getLastResolvedAddressesCount()) {
    // Try next resolved address for current hostname
    std::unique_ptr<Client::FailInfo> info(static_cast<Client::FailInfo *>(e.getData()));

    LOG_WARN("failed to connect to server=%s, trying next resolved address", qPrintable(info->m_what));
    if (!m_suspended) {
      scheduleClientRestart(retryTime());
    }
  } else {
    // All resolved addresses exhausted, try next server in list
    m_lastServerAddressIndex = 0;
    tryNextServer();

    if (m_currentServerIndex == 0) {
      // We've cycled through all servers, treat as refused
      handleClientRefused(e);
    } else {
      std::unique_ptr<Client::FailInfo> info(static_cast<Client::FailInfo *>(e.getData()));
      LOG_WARN("failed to connect to server=%s, trying next server in list", qPrintable(info->m_what));
      if (!m_suspended) {
        scheduleClientRestart(retryTime());
      }
    }
  }
}

void ClientApp::handleClientRefused(const Event &e)
{
  std::unique_ptr<Client::FailInfo> info(static_cast<Client::FailInfo *>(e.getData()));

  if (!info->m_retry) {
    LOG_ERR("failed to connect to server: %s", qPrintable(info->m_what));
    getEvents()->addEvent(Event(EventTypes::Quit));
  } else {
    LOG_WARN("failed to connect to server: %s", qPrintable(info->m_what));
    if (!m_suspended) {
      scheduleClientRestart(retryTime());
      m_retryCount++;
    }
  }
}

void ClientApp::handleClientDisconnected()
{
  m_retryCount = 0;
  LOG_DEBUG("disconnected from server");
  ipcSendConnectionState(deskflow::core::ConnectionState::Disconnected);
  if (!m_suspended) {
    scheduleClientRestart(retryTime());
  }
}

Client *ClientApp::openClient(const std::string &name, const NetworkAddress &address, deskflow::Computer *computer)
{
  auto *client = new Client(getEvents(), name, address, getSocketFactory(), computer);

  try {
    getEvents()->addHandler(EventTypes::ClientConnected, client->getEventTarget(), [this](const auto &) {
      handleClientConnected();
    });
    getEvents()->addHandler(EventTypes::ClientConnectionFailed, client->getEventTarget(), [this](const auto &e) {
      handleClientFailed(e);
    });
    getEvents()->addHandler(EventTypes::ClientConnectionRefused, client->getEventTarget(), [this](const auto &e) {
      handleClientRefused(e);
    });
    getEvents()->addHandler(EventTypes::ClientDisconnected, client->getEventTarget(), [this](const auto &) {
      handleClientDisconnected();
    });

  } catch (std::bad_alloc &ba) {
    delete client;
    throw ba;
  }

  return client;
}

void ClientApp::closeClient(Client *client)
{
  if (client == nullptr) {
    return;
  }
  using enum EventTypes;
  auto *target = client->getEventTarget();
  getEvents()->removeHandler(ClientConnected, target);
  getEvents()->removeHandler(ClientConnectionFailed, target);
  getEvents()->removeHandler(ClientConnectionRefused, target);
  getEvents()->removeHandler(ClientDisconnected, target);
  delete client;
}

bool ClientApp::startClient()
{
  deskflow::Computer *clientComputer = nullptr;
  try {
    if (m_clientComputer == nullptr) {
      clientComputer = openClientComputer();
      m_client = openClient(
          Settings::value(Settings::Core::ComputerName).toString().toStdString(), getCurrentServerAddress(),
          clientComputer
      );
      m_clientComputer = clientComputer;
      LOG_INFO("started client");
    }

    m_client->setServerAddress(getCurrentServerAddress());
    m_client->connect(m_lastServerAddressIndex);

    return true;
  } catch (X11DisplayUnavailableException &e) {
    LOG_WARN("secondary computer unavailable: %s", e.what());
    closeClientComputer(clientComputer);
  } catch (DisplayOpenFailureException &e) {
    LOG_CRIT("failed to start client: %s", e.what());
    closeClientComputer(clientComputer);
    m_retryCount = 0;
    return false;
  } catch (BaseException &e) {
    LOG_CRIT("failed to start client: %s", e.what());
    closeClientComputer(clientComputer);
    m_retryCount = 0;
    return false;
  }

  scheduleClientRestart(retryTime());
  return true;
}

void ClientApp::stopClient()
{
  closeClient(m_client);
  closeClientComputer(m_clientComputer);
  m_client = nullptr;
  m_clientComputer = nullptr;
  m_retryCount = 0;
}

int ClientApp::mainLoop()
{
  // create socket multiplexer.  this must happen after daemonization
  // on unix because threads evaporate across a fork().
  setSocketMultiplexer(std::make_unique<SocketMultiplexer>());

  // start client, etc
  startNode();

  // run event loop.  if startClient() failed we're supposed to retry
  // later.  the timer installed by startClient() will take care of
  // that.
  int exitCode = getEvents()->loop();

  // close down
  LOG_DEBUG("stopping client");
  stopClient();
  LOG_INFO("stopped client");

  return exitCode;
}

int ClientApp::start()
{
  initApp();
  return mainLoop();
}

int ClientApp::runInner(StartupFunc startup)
{
  int result;
  try {
    // run
    result = startup();
  } catch (...) {
    throw;
  }

  return result;
}

NetworkAddress &ClientApp::getCurrentServerAddress()
{
  if (m_serverAddresses.isEmpty()) {
    throw std::runtime_error("No server addresses configured");
  }
  return m_serverAddresses[m_currentServerIndex];
}

void ClientApp::tryNextServer()
{
  if (m_serverAddresses.size() > 1) {
    m_currentServerIndex = (m_currentServerIndex + 1) % m_serverAddresses.size();
    LOG_DEBUG("switching to server %zu of %zu", m_currentServerIndex + 1, m_serverAddresses.size());
  }
}

void ClientApp::startNode()
{
  // start the client.  if this return false then we've failed and
  // we shouldn't retry.
  LOG_VERBOSE("starting client");
  if (!startClient()) {
    bye(s_exitFailed);
  }
}

ISocketFactory *ClientApp::getSocketFactory() const
{
  return new TCPSocketFactory(getEvents(), getSocketMultiplexer());
}

double ClientApp::retryTime() const
{
  if (!Settings::value(Settings::Client::DynamicConnectionRetry).toBool() || m_retryCount < 300) // 5 minutes
    return 1;
  if (m_retryCount < 360) // 5 minutes
    return 5;
  if (m_retryCount < 390) // 5 minutes
    return 10;
  if (m_retryCount < 410) // 10 minutes
    return 30;
  if (m_retryCount < 420) // 10 minutes
    return 60;
  if (m_retryCount < 430) // 20 minutes
    return 120;
  return 300;
}
