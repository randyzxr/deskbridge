/*
 * Deskflow -- mouse and keyboard sharing utility
 * SPDX-FileCopyrightText: (C) 2012 - 2016 Synergy App Ltd
 * SPDX-FileCopyrightText: (C) 2004 Chris Schoeneman
 * SPDX-License-Identifier: GPL-2.0-only WITH LicenseRef-OpenSSL-Exception
 */

#include "deskflow/IPrimaryComputer.h"

#include <cstdlib>

//
// IPrimaryComputer::ButtonInfo
//

IPrimaryComputer::ButtonInfo *IPrimaryComputer::ButtonInfo::alloc(ButtonID id, KeyModifierMask mask)
{
  auto *info = (ButtonInfo *)malloc(sizeof(ButtonInfo));
  info->m_button = id;
  info->m_mask = mask;
  return info;
}

IPrimaryComputer::ButtonInfo *IPrimaryComputer::ButtonInfo::alloc(const ButtonInfo &x)
{
  auto *info = (ButtonInfo *)malloc(sizeof(ButtonInfo));
  info->m_button = x.m_button;
  info->m_mask = x.m_mask;
  return info;
}

bool IPrimaryComputer::ButtonInfo::equal(const ButtonInfo *a, const ButtonInfo *b)
{
  return (a->m_button == b->m_button && a->m_mask == b->m_mask);
}

//
// IPrimaryComputer::MotionInfo
//

IPrimaryComputer::MotionInfo *IPrimaryComputer::MotionInfo::alloc(int32_t x, int32_t y)
{
  auto *info = (MotionInfo *)malloc(sizeof(MotionInfo));
  info->m_x = x;
  info->m_y = y;
  return info;
}

//
// IPrimaryComputer::WheelInfo
//

IPrimaryComputer::WheelInfo *IPrimaryComputer::WheelInfo::alloc(int32_t xDelta, int32_t yDelta)
{
  auto *info = (WheelInfo *)malloc(sizeof(WheelInfo));
  info->m_xDelta = xDelta;
  info->m_yDelta = yDelta;
  return info;
}

//
// IPrimaryComputer::HotKeyInfo
//

IPrimaryComputer::HotKeyInfo *IPrimaryComputer::HotKeyInfo::alloc(uint32_t id)
{
  auto *info = (HotKeyInfo *)malloc(sizeof(HotKeyInfo));
  info->m_id = id;
  return info;
}

//
// IPrimaryComputer::EiConnectInfo
//

IPrimaryComputer::EiConnectInfo *IPrimaryComputer::EiConnectInfo::alloc(int fd)
{
  auto *info = (EiConnectInfo *)malloc(sizeof(EiConnectInfo));
  info->m_fd = fd;
  return info;
}
