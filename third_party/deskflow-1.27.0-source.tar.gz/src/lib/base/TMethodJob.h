/*
 * Deskflow -- mouse and keyboard sharing utility
 * SPDX-FileCopyrightText: (C) 2012 - 2016 Synergy App Ltd
 * SPDX-FileCopyrightText: (C) 2002 Chris Schoeneman
 * SPDX-License-Identifier: GPL-2.0-only WITH LicenseRef-OpenSSL-Exception
 */

#pragma once

#include "IJob.h"

//! Use a function as a job
/*!
A job class that invokes a member function.
*/
template <class T> class TMethodJob : public IJob
{
public:
  //! run() invokes \c object->method(arg)
  TMethodJob(T *object, void (T::*method)(const void *), void *arg = nullptr);
  ~TMethodJob() override = default;

  // IJob overrides
  void run() override;

private:
  T *m_object;
  void (T::*m_method)(const void *);
  void *m_arg;
};

template <class T>
inline TMethodJob<T>::TMethodJob(T *object, void (T::*method)(const void *), void *arg)
    : m_object(object),
      m_method(method),
      m_arg(arg)
{
  // do nothing
}

template <class T> inline void TMethodJob<T>::run()
{
  if (m_object != nullptr) {
    (m_object->*m_method)(m_arg);
  }
}
